package question15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class PClass {

    public static void main(String[] args) {
        Hashtable<Integer, String> htable = new Hashtable<>();
        htable.put(1, "sai");
        htable.put(2, "prabhas");
        htable.put(3, "NTR");
        HashMap<Integer, String> hmap = new HashMap<>();
        hmap.put(1, "Nag");
        hmap.put(2, "Sam");
        hmap.put(3, "Sruthi");
        System.out.println("Hashtable:");
        for (Map.Entry<Integer, String> entry : htable.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        System.out.println("HashMap:");
        for (Map.Entry<Integer, String> entry : hmap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
