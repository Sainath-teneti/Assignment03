package question5;

public class Ques5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer a = new StringBuffer("Oops is");
		 a.append(" Programming language");
		 System.out.println(a); 

		 StringBuilder b = new StringBuilder("Oops is");
		 b.append(" Programming language");
		 System.out.println(b);
	}

}
