package question17;

import java.util.ArrayList;
import java.util.List;

public class PClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> l1 = new ArrayList<>();
		l1.add(9);
		l1.add(8);
		l1.add(7);
		l1.add(6);
		for(Integer in : l1) {
			if (in == 3) {
				l1.remove(Integer.valueOf(in)); 
			}
		}
        System.out.println(l1);
		/* Fail-Safe Iterator example
		Map<Integer, Integer> m = new ConcurrentHashMap<>();
		map.put(1, 9);
		map.put(2, 8);
		map.put(3, 7);
		Iterator<Integer> mitr = map.keySet().iterator();
		while (mitr.hasNext()) {
			int k = mitr.next();
			if (k == 3) {
				map.put(4, 4); 
			}
		} 
           */
	}


}
