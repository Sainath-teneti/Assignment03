package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PClass {


		public static void main(String[] args) {
			
			List<String> ls = new ArrayList<>();
			ls.add("1");
			ls.add("2");
			ls.add("3");
			ls.add("4");
			List<String> syncList = Collections.synchronizedList(ls);
			synchronized (syncList) {
				System.out.println("synchronized list is: " + syncList.size());
			}
			synchronized (syncList) {
				syncList.add("5");
				syncList.add("6");
			}
			synchronized (syncList) {
				System.out.println("Synchronized list is: " + syncList);
			}
		}


}
