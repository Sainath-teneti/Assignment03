package question6;

public class Ques6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String oop = "Oops is";
		oop = oop.concat(" Programming language");
        System.out.println(oop);

        
        StringBuffer pl = new StringBuffer("Oops is");
        pl.append(" Programming language");
        System.out.println(pl);
	}

}
