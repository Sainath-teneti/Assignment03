package question18;

public class PClass extends Thread {

	public void run() {
	     System.out.println("Thread in this class Started");
		}
public static void main(String args[]) {
	PClass t = new PClass();
	t.start();
	t.start();
					
  }


}
