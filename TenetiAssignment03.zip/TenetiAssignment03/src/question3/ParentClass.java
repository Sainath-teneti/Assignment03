package question3;

public class ParentClass {
	
	public ParentClass reproduce() {
		System.out.println("Parentclass");
        return new ParentClass();
    }

}
