package question3;

public class ChildClass extends ParentClass{

		public ChildClass reproduce() {
			System.out.println("child");
	        return new ChildClass();
	    }
		
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub

			ChildClass obj = new ChildClass();
			ChildClass obj1 = obj.reproduce();
			System.out.println(obj1.getClass());
		}
	}


