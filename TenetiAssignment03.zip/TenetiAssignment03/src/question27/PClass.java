package question27;

public class PClass {

	private static PClass instance;

	private PClass() {}

	public static synchronized PClass getInstance() {
		if (instance == null) {
			System.out.println("SingletonSyncDemo");
			instance = new PClass();
		}
		return instance;
	}

	public void showMessage() {
		System.out.println("Hii, World!");
	}

	public static void main(String[] args) {
		System.out.println("SingletonSyncDemo");
		PClass ob1 = PClass.getInstance();

		System.out.println("SingletonSyncDemo again");
		PClass ob2 = PClass.getInstance();

		System.out.println("instances " + (ob1 == ob2));

		System.out.println("method on object1");
		ob1.showMessage();

		System.out.println("method on object2");
		ob2.showMessage();
	}

}
