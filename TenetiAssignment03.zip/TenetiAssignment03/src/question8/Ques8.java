package question8;

import java.util.Scanner;

public class Ques8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
        try {
            System.out.print("Enter a name: ");
            String name = s.nextLine();
            System.out.println("You entered: " + name);
        } finally {
            s.close();
        }
	}

}
