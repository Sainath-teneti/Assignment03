package question21;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class PClass implements Serializable{

	private String name;
    private int age;
    private double price;

   public PClass(String name, int age, double price) {
		super();
		this.name = name;
		this.age = age;
		this.price = price;
	}


	public static void main(String[] args) throws Exception {
		PClass c = new PClass("Sai", 9, 500.0);

        // Serialization
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("PClass.ser"));
        out.writeObject(c);
        out.close();

        // Deserialization
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("PClass"
        		+ ""
        		+ ".ser"));
        PClass c1 = (PClass) in.readObject();
        in.close();

        System.out.println("Name: " + c1.name);
        System.out.println("Age: " + c1.age);
        System.out.println("Salary: " + c1.price);
    }

}