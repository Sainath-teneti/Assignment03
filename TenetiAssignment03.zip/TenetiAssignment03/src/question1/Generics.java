package question1;

public class Generics<M> {
	
	 private M valv;

	    public M getValv() {
	        return valv;
	    }

	    public void setValue(M valv) {
	        this.valv = valv;
	    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Generics<String> p1 = new Generics<>();
		p1.setValue("Hello Java");
		String value = p1.getValv();
		System.out.println(value);
	}
	}