package question22;

public class PClass {
	 public static void main(String[] args) {
	        String s1 = "I ";
	        System.out.println("Original: " + s1);

	        // Appending a string to the original string
	        s1 += " am";
	        System.out.println("Changed: " + s1);

	        // Reassigning the original string to a new value
	        s1 = "Sainath";
	        System.out.println("Brand New: " + s1);
	    }
}