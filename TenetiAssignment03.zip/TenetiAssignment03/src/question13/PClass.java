package question13;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class PClass {

	 public static void main(String[] args) {
	       
	        List<String> list = new Vector<>();
	        list.add("1");
	        list.add("2");
	        list.add("3");
	       
	        List<String> list2 = new ArrayList<>();
	        list2.add("4");
	        list2.add("5");
	        list2.add("6");
	        
	        for (String name : list) {
	            System.out.println(name);
	        }
	        
	        for (String name : list2) {
	            System.out.println(name);
	        }
	    }
	}