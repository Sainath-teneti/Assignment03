package question26;

public class PClass {

	private static final PClass instance = new PClass();

	private PClass() {
		System.out.println("PClass instance.");
	}

	public static PClass getInstance() {
		return instance;
	}

	public void showMessage() {
		System.out.println("PClass object.");
	}

	public static void main(String[] args) {
		PClass p1 = PClass.getInstance();
		PClass p2 = PClass.getInstance();

		System.out.println("p1 hash code: " + p1.hashCode());
		System.out.println("p2 hash code: " + p2.hashCode());

		p1.showMessage();
	}

}
