package question19;

public class ParentClass implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
	System.out.println("using Runnable");	
	}
	
}