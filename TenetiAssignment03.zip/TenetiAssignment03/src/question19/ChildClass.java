package question19;

public class ChildClass extends Thread {
public void run() {
	System.out.println(" extending Thread");
	}

public static void main(String args[]) {
	ChildClass c = new ChildClass();
	c.start();
	ParentClass m = new ParentClass();
	Thread d1 = new Thread(m);
	d1.start();
}
}
