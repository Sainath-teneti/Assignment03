package question10;

import java.io.FileNotFoundException;

public class ChildClass extends ParentClass {

	public void doSomething() throws FileNotFoundException {
		System.out.println("ClassB");
        
    }
	public static void main(String args[]) {
		ChildClass s = new ChildClass();
		try {
			s.doSomething();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
