package question10;

import java.io.IOException;

public class ParentClass {
	
	 public void doSomething() throws IOException {
	       System.out.println("This is in ClassA");
	    }
}