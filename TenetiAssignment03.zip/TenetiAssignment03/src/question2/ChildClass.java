package question2;

public class ChildClass extends ParentClass{

	
	//	private void method1() {
//			System.out.println("Method One in Sub Class B ");
//		}
		@Override
		 void method2() {
			 System.out.println("Method Two in Sub Class B ");
		 }
		@Override
		 protected void method3() {
			 System.out.println("Method Three in Sub Class B ");
		 }
		@Override
		 public void method4() {
			 System.out.println("Method Four in Sub Class B ");
		 }	
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			ChildClass a  = new ChildClass();
			a.method2();
			a.method3();
			a.method4();
			

		}

}
