package question2;

public class ParentClass {
	private void method1() {
		System.out.println("Method One in Super Class A ");
	}
	 void method2() {
		 System.out.println("Method Two in Super Class A ");
	 }
	 protected void method3() {
		 System.out.println("Method Three in Super Class A ");
	 }
	 public void method4() {
		 System.out.println("Method Four in Super Class A ");
	 }
}
