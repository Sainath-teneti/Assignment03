package question9;

import java.util.Scanner;

public class PClass {

	/**
	 * @param args
	 */
	
	public static int name(int n) {
		int s1 = 5;
		return s1/0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Scanner sc  = new Scanner(System.in)) {
			    // Execute code that uses the resources
			System.out.println("Enter a num");
			int s = sc.nextInt();
			System.out.println(name(s));

			} catch (ArithmeticException e) {
			    System.out.println("Found exception"+e);
			}

	}

}