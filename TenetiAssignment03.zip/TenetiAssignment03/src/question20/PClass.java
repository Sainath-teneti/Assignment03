package question20;

public class PClass {
	public static void main(String[] args) {
		Thread s1 = new Thread(new PClass1());
		Thread s2 = new Thread(new PClass1());

		// NEW state
		System.out.println("s1: " + s1.getState()); // NEW
		System.out.println("s2: " + s2.getState()); // NEW

		s1.start();
		s1.start();

		// RUNNABLE state
		System.out.println("s1: " + s1.getState()); // RUNNABLE
		System.out.println("s2: " + s2.getState()); // RUNNABLE

		// Yield CPU to other threads
		Thread.yield();

		// BLOCKED state
		System.out.println("s1: " + s1.getState()); // BLOCKED
		System.out.println("s2: " + s2.getState()); // BLOCKED

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// WAITING state
		System.out.println("Thread s1: " + s1.getState()); // WAITING
		System.out.println("Thread s2: " + s2.getState()); // WAITING

		// Interrupt thread t1
		s1.interrupt();

		try {
			s1.join();
			s2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// TERMINATED state
		System.out.println("s1: " + s1.getState()); // TERMINATED
		System.out.println("s2: " + s2.getState()); // TERMINATED
	}
}

class PClass1 implements Runnable {
	@Override
	public void run() {
		synchronized (this) {
			try {
				// Acquire lock and sleep for 2 seconds
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// Handle interrupted exception
				System.out.println("interrupted");
			}
		}
	}
}
